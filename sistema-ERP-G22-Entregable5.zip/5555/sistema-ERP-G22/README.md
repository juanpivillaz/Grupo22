# Sistema CRM - Gestión de Productos con Flask y SQLite

Sistema web completo para la gestión de productos (CRUD) desarrollado con Flask y SQLite. Incluye una interfaz moderna y elegante basada en Bootstrap.

## 🚀 Características

- **CRUD Completo de Productos**: Crear, leer, actualizar y eliminar productos
- **Gestión de Categorías**: Organización sistemática de productos
- **Gestión de Proveedores**: Información completa de empresas proveedoras
- **Control de Stock**: Monitoreo de inventario con alertas de stock bajo
- **Interfaz Moderna**: Diseño responsive con Bootstrap 5
- **Base de Datos SQLite**: Base de datos ligera y fácil de usar

## 📋 Funcionalidades

### Productos
- ✅ Agregar nuevos productos
- ✅ Editar productos existentes
- ✅ Eliminar productos (marcado como inactivo)
- ✅ Visualizar detalles completos
- ✅ Calculación automática de márgenes
- ✅ Control de stock actual y mínimo

### Categorías
- ✅ Crear y gestionar categorías
- ✅ Asignación de productos a categorías
- ✅ Estadísticas por categoría

### Proveedores
- ✅ Registro de información de proveedores
- ✅ Datos de contacto completos
- ✅ Asociación productos-proveedores

### Dashboard
- ✅ Resumen estadístico de inventario
- ✅ Alertas de stock bajo
- ✅ Indicadores visuales de estado de stock

## 🛠️ Instalación

### Requisitos Previos
- Python 3.8 o superior
- pip (gestor de paquetes de Python)

### Pasos de Instalación

1. **Clonar o descargar el proyecto**
   ```bash
   git clone [URL_DEL_REPOSITORIO]
   cd sistema-crm-productos
   ```

2. **Crear entorno virtual**
   ```bash
   python -m venv venv
   ```

3. **Activar entorno virtual**
   
   **En Windows:**
   ```bash
   venv\Scripts\activate
   ```
   
   **En macOS/Linux:**
   ```bash
   source venv/bin/activate
   ```

4. **Instalar dependencias**
   ```bash
   pip install -r requirements.txt
   ```

5. **Ejecutar la aplicación**
   ```bash
   python app.py
   ```

6. **Acceder a la aplicación**
   Abrir el navegador y dirigirse a: `http://localhost:5000`

## 📁 Estructura del Proyecto

```
sistema-crm-productos/
├── app.py                 # Aplicación principal de Flask
├── requirements.txt       # Dependencias del proyecto
├── README.md             # Documentación del proyecto
├── productos.db          # Base de datos SQLite (se crea automáticamente)
├── bd                    # Script SQL de estructura de base de datos
└── templates/            # Plantillas HTML
    ├── base.html         # Plantilla base
    ├── index.html        # Lista de productos
    ├── agregar_producto.html
    ├── editar_producto.html
    ├── ver_producto.html
    ├── stock_bajo.html
    ├── categorias.html
    ├── agregar_categoria.html
    ├── proveedores.html
    └── agregar_proveedor.html
```

## 🎯 Uso del Sistema

### Agregar un Nuevo Producto
1. Ir a la página principal
2. Hacer clic en "Nuevo Producto"
3. Completar el formulario con:
   - Código único del producto
   - Nombre del producto
   - Descripción (opcional)
   - Precio de costó
   - Precio de venta
   - Categoría (requerido)
   - Proveedor (opcional)
   - Stock inicial y mínimo

### Gestión de Categorías
1. Navegar a "Categorías" en el menú principal
2. Agregar nuevas categorías según necesidad
3. Usar categorías para organizar productos

### Monitoreo de Stock
1. El sistema calcula automáticamente los márgenes
2. Alertas visuales para productos con stock bajo
3. Acceso rápido a reportes de stock en "Stock Bajo"

## 🎨 Personalización

El sistema está diseñado para ser fácilmente personalizable:

- **Colores**: Modificar las clases CSS en `templates/base.html`
- **Funcionalidades**: Agregar nuevas rutas y funciones en `app.py`
- **Base de datos**: Modificar modelos en `app.py` para nuevos campos

## 🔧 Configuración Avanzada

### Cambiar Puerto de Ejecución
En `app.py`, línea 369:
```python
app.run(debug=True, host='0.0.0.0', port=5000)
```

### Configurar Base de Datos
Para usar PostgreSQL o MySQL en lugar de SQLite:
```python
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://usuario:password@localhost/base_datos'
```

## 🐛 Solución de Problemas

### Error: "No module named 'flask'"
Asegúrate de haber instalado las dependencias:
```bash
pip install -r requirements.txt
```

### Error: "Port already in use"
Cambiar el puerto en `app.py`:
```python
app.run(debug=True, host='0.0.0.0', port=5001)
```

### Base de datos no se crea
Verificar permisos de escritura en el directorio del proyecto.

## 📝 Características Técnicas

- **Framework**: Flask 3.0.0
- **ORM**: SQLAlchemy
- **Base de Datos**: SQLite (configurable)
- **Frontend**: Bootstrap 5 + Font Awesome
- **Tipo de Arquitectura**: MVC (Modelo-Vista-Controlador)
- **Responsive**: Diseño adaptable a móviles y tablets

## 🤝 Contribuciones

Las contribuciones son bienvenidas. Para contribuir:

1. Fork el proyecto
2. Crear una rama para tu feature (`git checkout -b feature/AmazingFeature`)
3. Commit tus cambios (`git commit -m 'Add some AmazingFeature'`)
4. Push a la rama (`git push origin feature/AmazingFeature`)
5. Abrir un Pull Request

## 📄 Licencia

Este proyecto está bajo la Licencia MIT. Ver el archivo `LICENSE` para más detalles.

## 📞 Soporte

Para soporte técnico o consultas:
- Crear un issue en el repositorio del proyecto
- Contactar al desarrollador

---

**Desarrollado con ❤️ usando Flask y Bootstrap**
