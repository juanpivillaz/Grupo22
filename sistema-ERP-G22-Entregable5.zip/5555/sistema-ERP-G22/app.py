from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os
import re
import hashlib
from functools import wraps
import secrets
import string
from werkzeug.utils import secure_filename

# Configuración de la aplicación Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'tu_clave_secreta_aqui_2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///productos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'webp'}

# Crear directorio de uploads si no existe
static_dir = os.path.join(app.root_path, 'static')
uploads_dir = os.path.join(static_dir, 'uploads')
os.makedirs(uploads_dir, exist_ok=True)

# Inicializar SQLAlchemy
db = SQLAlchemy(app)

# Modelo para cada tabla de la base de datos
class Categoria(db.Model):
    __tablename__ = 'categorias'
    id_categoria = db.Column(db.Integer, primary_key=True)
    nombre_categoria = db.Column(db.String(100), unique=True, nullable=False)
    descripcion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Categoria {self.nombre_categoria}>'

class Proveedor(db.Model):
    __tablename__ = 'proveedores'
    id_proveedor = db.Column(db.Integer, primary_key=True)
    nombre_proveedor = db.Column(db.String(100), nullable=False)
    contacto = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Proveedor {self.nombre_proveedor}>'

class Articulo(db.Model):
    __tablename__ = 'articulos'
    id_articulo = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), unique=True, nullable=False)
    nombre_breve = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    costo = db.Column(db.Float, nullable=False, default=0.0)
    precio = db.Column(db.Float, nullable=False, default=0.0)
    id_proveedor = db.Column(db.Integer, db.ForeignKey('proveedores.id_proveedor'))
    id_categoria = db.Column(db.Integer, db.ForeignKey('categorias.id_categoria'), nullable=False)
    stock_actual = db.Column(db.Integer, default=0)
    stock_minimo = db.Column(db.Integer, default=0)
    imagen_url = db.Column(db.String(255))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    # Relaciones
    categoria = db.relationship('Categoria', backref='articulos')
    proveedor = db.relationship('Proveedor', backref='articulos')
    
    def __repr__(self):
        return f'<Articulo {self.nombre_breve}>'

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    nombre_apellido = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    dni = db.Column(db.String(20), unique=True, nullable=False)
    calle = db.Column(db.String(200), nullable=False)
    numero = db.Column(db.String(20), nullable=False)
    codigo_postal = db.Column(db.String(20), nullable=False)
    rol = db.Column(db.String(50), nullable=False)  # administrador, analista, gerente
    estado = db.Column(db.String(20), default='activo')  # activo, inactivo
    contraseña_hash = db.Column(db.String(255), nullable=False)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    ultimo_acceso = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<Usuario {self.nombre_apellido}>'
    
    def verificar_contraseña(self, contraseña):
        """Verificar contraseña usando hash SHA-256"""
        return hashlib.sha256(contraseña.encode()).hexdigest() == self.contraseña_hash
    
    def establecer_contraseña(self, contraseña):
        """Establecer contraseña con hash SHA-256"""
        self.contraseña_hash = hashlib.sha256(contraseña.encode()).hexdigest()

class Cliente(db.Model):
    __tablename__ = 'clientes'
    id_cliente = db.Column(db.Integer, primary_key=True)
    nombre = db.Column(db.String(50), nullable=False)
    apellido = db.Column(db.String(50), nullable=False)
    dni = db.Column(db.String(20), unique=True, nullable=False)
    direccion = db.Column(db.Text)
    email = db.Column(db.String(100), unique=True)
    celular = db.Column(db.String(20))
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    # Relación con órdenes
    ordenes = db.relationship('OrdenVenta', backref='cliente', lazy=True)
    
    def __repr__(self):
        return f'<Cliente {self.nombre} {self.apellido}>'

class OrdenVenta(db.Model):
    __tablename__ = 'ordenes_venta'
    id_orden = db.Column(db.Integer, primary_key=True)
    numero_orden = db.Column(db.String(50), unique=True, nullable=False)
    id_cliente = db.Column(db.Integer, db.ForeignKey('clientes.id_cliente'), nullable=False)
    id_usuario_vendedor = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    fecha_orden = db.Column(db.DateTime, default=datetime.utcnow)
    fecha_entrega_estimada = db.Column(db.Date)
    estado = db.Column(db.String(20), default='PENDIENTE')  # PENDIENTE, CONFIRMADA, EN_PREPARACION, DESPACHADA, ENTREGADA, CANCELADA
    subtotal = db.Column(db.Float, default=0.0)
    impuestos = db.Column(db.Float, default=0.0)
    total = db.Column(db.Float, default=0.0)
    direccion_entrega = db.Column(db.Text, nullable=False)
    observaciones = db.Column(db.Text)
    
    # Relaciones
    vendedor = db.relationship('Usuario', backref='ordenes_venta')
    detalles = db.relationship('DetalleOrden', backref='orden_venta', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<OrdenVenta {self.numero_orden}>'

class DetalleOrden(db.Model):
    __tablename__ = 'detalles_orden'
    id_detalle = db.Column(db.Integer, primary_key=True)
    id_orden = db.Column(db.Integer, db.ForeignKey('ordenes_venta.id_orden'), nullable=False)
    id_articulo = db.Column(db.Integer, db.ForeignKey('articulos.id_articulo'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_unitario = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    
    # Relación
    articulo = db.relationship('Articulo', backref='detalles_orden')
    
    def __repr__(self):
        return f'<DetalleOrden {self.id_detalle}>'

class OrdenCompra(db.Model):
    __tablename__ = 'ordenes_compra'
    id_orden_compra = db.Column(db.Integer, primary_key=True)
    numero_orden = db.Column(db.String(50), unique=True, nullable=False)
    id_proveedor = db.Column(db.Integer, db.ForeignKey('proveedores.id_proveedor'), nullable=False)
    id_usuario_comprador = db.Column(db.Integer, db.ForeignKey('usuarios.id'), nullable=False)
    fecha_orden = db.Column(db.DateTime, default=datetime.utcnow)
    fecha_entrega_estimada = db.Column(db.Date)
    estado = db.Column(db.String(20), default='PENDIENTE')  # PENDIENTE, CONFIRMADA, RECIBIDA, CANCELADA
    subtotal = db.Column(db.Float, default=0.0)
    impuestos = db.Column(db.Float, default=0.0)
    total = db.Column(db.Float, default=0.0)
    observaciones = db.Column(db.Text)
    
    # Relaciones
    proveedor = db.relationship('Proveedor', backref='ordenes_compra')
    comprador = db.relationship('Usuario', backref='ordenes_compra')
    detalles = db.relationship('DetalleOrdenCompra', backref='orden_compra', cascade='all, delete-orphan')
    
    def __repr__(self):
        return f'<OrdenCompra {self.numero_orden}>'

class DetalleOrdenCompra(db.Model):
    __tablename__ = 'detalles_orden_compra'
    id_detalle = db.Column(db.Integer, primary_key=True)
    id_orden_compra = db.Column(db.Integer, db.ForeignKey('ordenes_compra.id_orden_compra'), nullable=False)
    id_articulo = db.Column(db.Integer, db.ForeignKey('articulos.id_articulo'), nullable=False)
    cantidad = db.Column(db.Integer, nullable=False, default=1)
    precio_unitario = db.Column(db.Float, nullable=False)
    subtotal = db.Column(db.Float, nullable=False)
    
    # Relación
    articulo = db.relationship('Articulo', backref='detalles_orden_compra')
    
    def __repr__(self):
        return f'<DetalleOrdenCompra {self.id_detalle}>'

# Funciones auxiliares
def allowed_file(filename):
    """Verificar si el archivo tiene una extensión permitida"""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Funciones de validación
def validar_contraseña(contraseña):
    """
    Validar contraseña según los requisitos:
    - Mínimo 8 caracteres, máximo 16
    - Al menos un símbolo
    - Al menos un número
    - Al menos una mayúscula
    - Al menos una minúscula
    """
    if len(contraseña) < 8 or len(contraseña) > 16:
        return False, "La contraseña debe tener entre 8 y 16 caracteres"
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', contraseña):
        return False, "La contraseña debe contener al menos un símbolo"
    
    if not re.search(r'\d', contraseña):
        return False, "La contraseña debe contener al menos un número"
    
    if not re.search(r'[A-Z]', contraseña):
        return False, "La contraseña debe contener al menos una mayúscula"
    
    if not re.search(r'[a-z]', contraseña):
        return False, "La contraseña debe contener al menos una minúscula"
    
    return True, "Contraseña válida"

def login_required(f):
    """Decorador para requerir autenticación"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """Decorador para requerir rol de administrador"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', 'error')
            return redirect(url_for('login'))
        
        user = Usuario.query.get(session['user_id'])
        if not user or user.rol != 'administrador':
            flash('No tienes permisos para acceder a esta página', 'error')
            return redirect(url_for('menu_inicial'))
        
        return f(*args, **kwargs)
    return decorated_function

# Sistema de permisos por rol
PERMISOS_POR_ROL = {
    'administrador': {
        'inicio': True,
        'inventario': True,
        'productos': True,
        'categorias': True,
        'proveedores': True,
        'stock_bajo': True,
        'usuarios': True,
        'agregar_producto': True,
        'editar_producto': True,
        'eliminar_producto': True,
        'ver_producto': True,
        'agregar_categoria': True,
        'agregar_proveedor': True,
        'api_productos': True,
        'clientes': True,
        'agregar_cliente': True,
        'editar_cliente': True,
        'eliminar_cliente': True,
        'ver_cliente': True,
        'ventas': True,
        'procesar_venta': True,
        'ordenes_compra': True,
        'generar_compra': True
    },
    'gerente': {
        'inicio': True,
        'inventario': True,
        'productos': True,
        'categorias': True,
        'proveedores': True,
        'stock_bajo': True,
        'usuarios': False,
        'agregar_producto': True,
        'editar_producto': True,
        'eliminar_producto': True,
        'ver_producto': True,
        'agregar_categoria': True,
        'agregar_proveedor': True,
        'api_productos': True,
        'clientes': True,
        'agregar_cliente': True,
        'editar_cliente': True,
        'eliminar_cliente': True,
        'ver_cliente': True,
        'ventas': True,
        'procesar_venta': True,
        'ordenes_compra': True,
        'generar_compra': True
    },
    'analista': {
        'inicio': True,
        'inventario': True,
        'productos': False,
        'categorias': False,
        'proveedores': False,
        'stock_bajo': True,
        'usuarios': False,
        'agregar_producto': False,
        'editar_producto': False,
        'eliminar_producto': False,
        'ver_producto': False,
        'agregar_categoria': False,
        'agregar_proveedor': False,
        'api_productos': False,
        'clientes': False,
        'agregar_cliente': False,
        'editar_cliente': False,
        'eliminar_cliente': False,
        'ver_cliente': False,
        'ventas': False,
        'procesar_venta': False,
        'ordenes_compra': False,
        'generar_compra': False
    }
}

def verificar_permiso(permiso):
    """Verificar si el usuario actual tiene un permiso específico"""
    if 'user_role' not in session:
        return False
    
    rol = session['user_role']
    return PERMISOS_POR_ROL.get(rol, {}).get(permiso, False)

@app.context_processor
def inject_verificar_permiso():
    """Hacer disponible verificar_permiso en todas las plantillas"""
    return dict(verificar_permiso=verificar_permiso)

def permiso_required(permiso):
    """Decorador para requerir un permiso específico"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Debes iniciar sesión para acceder a esta página', 'error')
                return redirect(url_for('login'))
            
            # Verificar si la sesión ha expirado
            if 'last_activity' in session:
                last_activity = datetime.fromisoformat(session['last_activity'])
                if datetime.now() - last_activity > timedelta(minutes=10):
                    session.clear()
                    flash('Tu sesión ha expirado. Por favor, inicia sesión nuevamente', 'warning')
                    return redirect(url_for('login'))
            
            # Actualizar última actividad
            session['last_activity'] = datetime.now().isoformat()
            
            if not verificar_permiso(permiso):
                flash('No tienes permisos para acceder a esta página', 'error')
                return redirect(url_for('menu_inicial'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def generar_token_recuperacion():
    """Generar token seguro para recuperación de contraseña"""
    return ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(32))

def verificar_sesion_activa():
    """Verificar si la sesión está activa y no ha expirado"""
    if 'user_id' not in session:
        return False
    
    if 'last_activity' in session:
        last_activity = datetime.fromisoformat(session['last_activity'])
        if datetime.now() - last_activity > timedelta(minutes=10):
            session.clear()
            return False
    
    return True

# Rutas de autenticación
@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Página de inicio de sesión con validaciones mejoradas
    """
    # Si ya está logueado, redirigir según su rol
    if verificar_sesion_activa():
        return redirect(url_for('menu_inicial'))
    
    if request.method == 'POST':
        email = request.form['email']
        contraseña = request.form['contraseña']
        
        # Buscar usuario por email
        usuario = Usuario.query.filter_by(email=email).first()
        
        if not usuario:
            flash('Usuario y/o contraseña incorrecta', 'error')
            return render_template('login.html')
        
        # Verificar si el usuario está activo
        if usuario.estado != 'activo':
            flash('Tu cuenta está inactiva. Contacta al administrador', 'error')
            return render_template('login.html')
        
        # Verificar contraseña
        if not usuario.verificar_contraseña(contraseña):
            flash('Usuario y/o contraseña incorrecta', 'error')
            return render_template('login.html')
        
        # Login exitoso
        session['user_id'] = usuario.id
        session['user_name'] = usuario.nombre_apellido
        session['user_role'] = usuario.rol
        session['last_activity'] = datetime.now().isoformat()
        
        # Actualizar último acceso
        usuario.ultimo_acceso = datetime.utcnow()
        db.session.commit()
        
        flash(f'¡Bienvenido, {usuario.nombre_apellido}!', 'success')
        return redirect(url_for('menu_inicial'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """
    Cerrar sesión
    """
    session.clear()
    flash('Has cerrado sesión exitosamente', 'info')
    return redirect(url_for('login'))

@app.route('/recuperar-contraseña', methods=['GET', 'POST'])
def recuperar_contraseña():
    """
    Proceso de recuperación de contraseña
    """
    if request.method == 'POST':
        email = request.form['email']
        usuario = Usuario.query.filter_by(email=email, estado='activo').first()
        
        if usuario:
            # Generar nueva contraseña temporal
            nueva_contraseña = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(12))
            usuario.establecer_contraseña(nueva_contraseña)
            db.session.commit()
            
            flash(f'Se ha generado una nueva contraseña temporal: {nueva_contraseña}. Por favor, cámbiala después del primer login.', 'success')
            return redirect(url_for('login'))
        else:
            flash('No se encontró un usuario activo con ese email', 'error')
    
    return render_template('recuperar_contraseña.html')

@app.route('/cambiar-contraseña', methods=['GET', 'POST'])
@login_required
def cambiar_contraseña():
    """
    Cambiar contraseña del usuario logueado
    """
    if request.method == 'POST':
        contraseña_actual = request.form['contraseña_actual']
        nueva_contraseña = request.form['nueva_contraseña']
        confirmar_contraseña = request.form['confirmar_contraseña']
        
        usuario = Usuario.query.get(session['user_id'])
        
        # Verificar contraseña actual
        if not usuario.verificar_contraseña(contraseña_actual):
            flash('La contraseña actual es incorrecta', 'error')
            return render_template('cambiar_contraseña.html')
        
        # Validar nueva contraseña
        if nueva_contraseña != confirmar_contraseña:
            flash('Las contraseñas no coinciden', 'error')
            return render_template('cambiar_contraseña.html')
        
        es_valida, mensaje = validar_contraseña(nueva_contraseña)
        if not es_valida:
            flash(mensaje, 'error')
            return render_template('cambiar_contraseña.html')
        
        # Establecer nueva contraseña
        usuario.establecer_contraseña(nueva_contraseña)
        db.session.commit()
        
        flash('Contraseña cambiada exitosamente', 'success')
        return redirect(url_for('menu_inicial'))
    
    return render_template('cambiar_contraseña.html')

# Rutas de gestión de usuarios
@app.route('/usuarios')
@permiso_required('usuarios')
def usuarios():
    """
    Mostrar todos los usuarios
    """
    usuarios = Usuario.query.all()
    return render_template('usuarios.html', usuarios=usuarios)

@app.route('/usuario/agregar', methods=['GET', 'POST'])
@permiso_required('usuarios')
def agregar_usuario():
    """
    Agregar un nuevo usuario
    """
    if request.method == 'POST':
        try:
            # Validar contraseña
            contraseña = request.form['contraseña']
            confirmar_contraseña = request.form['confirmar_contraseña']
            
            if contraseña != confirmar_contraseña:
                flash('Las contraseñas no coinciden', 'error')
                return render_template('agregar_usuario.html')
            
            es_valida, mensaje = validar_contraseña(contraseña)
            if not es_valida:
                flash(mensaje, 'error')
                return render_template('agregar_usuario.html')
            
            # Verificar email único
            if Usuario.query.filter_by(email=request.form['email']).first():
                flash('El email ya está registrado', 'error')
                return render_template('agregar_usuario.html')
            
            # Verificar DNI único
            if Usuario.query.filter_by(dni=request.form['dni']).first():
                flash('El DNI ya está registrado', 'error')
                return render_template('agregar_usuario.html')
            
            usuario = Usuario(
                nombre_apellido=request.form['nombre_apellido'],
                email=request.form['email'],
                dni=request.form['dni'],
                calle=request.form['calle'],
                numero=request.form['numero'],
                codigo_postal=request.form['codigo_postal'],
                rol=request.form['rol']
            )
            
            usuario.establecer_contraseña(contraseña)
            
            db.session.add(usuario)
            db.session.commit()
            flash('¡Usuario agregado exitosamente!', 'success')
            return redirect(url_for('usuarios'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el usuario: {str(e)}', 'error')
    
    return render_template('agregar_usuario.html')

@app.route('/usuario/editar/<int:id>', methods=['GET', 'POST'])
@permiso_required('usuarios')
def editar_usuario(id):
    """
    Editar un usuario existente
    """
    usuario = Usuario.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            # Verificar email único (excepto el usuario actual)
            email_existente = Usuario.query.filter(
                Usuario.email == request.form['email'],
                Usuario.id != id
            ).first()
            if email_existente:
                flash('El email ya está registrado por otro usuario', 'error')
                return render_template('editar_usuario.html', usuario=usuario)
            
            # Verificar DNI único (excepto el usuario actual)
            dni_existente = Usuario.query.filter(
                Usuario.dni == request.form['dni'],
                Usuario.id != id
            ).first()
            if dni_existente:
                flash('El DNI ya está registrado por otro usuario', 'error')
                return render_template('editar_usuario.html', usuario=usuario)
            
            usuario.nombre_apellido = request.form['nombre_apellido']
            usuario.email = request.form['email']
            usuario.dni = request.form['dni']
            usuario.calle = request.form['calle']
            usuario.numero = request.form['numero']
            usuario.codigo_postal = request.form['codigo_postal']
            usuario.rol = request.form['rol']
            usuario.estado = request.form['estado']
            
            # Si se proporciona nueva contraseña, validarla y establecerla
            nueva_contraseña = request.form.get('nueva_contraseña')
            if nueva_contraseña:
                confirmar_contraseña = request.form.get('confirmar_contraseña')
                
                if nueva_contraseña != confirmar_contraseña:
                    flash('Las contraseñas no coinciden', 'error')
                    return render_template('editar_usuario.html', usuario=usuario)
                
                es_valida, mensaje = validar_contraseña(nueva_contraseña)
                if not es_valida:
                    flash(mensaje, 'error')
                    return render_template('editar_usuario.html', usuario=usuario)
                
                usuario.establecer_contraseña(nueva_contraseña)
            
            db.session.commit()
            flash('¡Usuario actualizado exitosamente!', 'success')
            return redirect(url_for('usuarios'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el usuario: {str(e)}', 'error')
    
    return render_template('editar_usuario.html', usuario=usuario)

@app.route('/usuario/eliminar/<int:id>', methods=['POST'])
@permiso_required('usuarios')
def eliminar_usuario(id):
    """
    Eliminar un usuario (marcar como inactivo)
    """
    try:
        usuario = Usuario.query.get_or_404(id)
        
        # No permitir eliminar el propio usuario
        if usuario.id == session['user_id']:
            flash('No puedes eliminar tu propio usuario', 'error')
            return redirect(url_for('usuarios'))
        
        usuario.estado = 'inactivo'
        db.session.commit()
        flash('¡Usuario eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el usuario: {str(e)}', 'error')
    
    return redirect(url_for('usuarios'))

@app.route('/usuario/ver/<int:id>')
@permiso_required('usuarios')
def ver_usuario(id):
    """
    Ver detalles de un usuario
    """
    usuario = Usuario.query.get_or_404(id)
    return render_template('ver_usuario.html', usuario=usuario)

# Rutas de la aplicación
@app.route('/')
@login_required
def menu_inicial():
    """
    Menú inicial estilo Odoo con acceso a todos los módulos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    productos_bajo_stock = len([p for p in productos if p.stock_actual <= p.stock_minimo])
    clientes = Cliente.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    
    return render_template('menu_inicial.html', 
                         productos=productos,
                         productos_bajo_stock=productos_bajo_stock,
                         clientes=clientes,
                         proveedores=proveedores)

@app.route('/inventario')
@permiso_required('inventario')
def inventario():
    """
    Página de inventario que muestra todos los productos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    
    # Calcular estadísticas
    productos_bajo_stock = len([p for p in productos if p.stock_actual <= p.stock_minimo])
    valor_total_productos = sum(p.precio for p in productos)
    margen_total_productos = sum(p.precio - p.costo for p in productos)
    
    return render_template('inventario.html', 
                         productos=productos,
                         productos_bajo_stock=productos_bajo_stock,
                         valor_total_productos=valor_total_productos,
                         margen_total_productos=margen_total_productos)

@app.route('/producto/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_producto')
def agregar_producto():
    """
    Agregar un nuevo producto
    """
    if request.method == 'POST':
        try:
            imagen_url = None
            # Procesar imagen si se subió
            if 'imagen' in request.files:
                file = request.files['imagen']
                if file and file.filename and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    # Agregar timestamp para evitar conflictos
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                    filename = timestamp + filename
                    # Crear ruta completa
                    upload_path = os.path.join(app.root_path, 'static', 'uploads')
                    os.makedirs(upload_path, exist_ok=True)
                    filepath = os.path.join(upload_path, filename)
                    file.save(filepath)
                    imagen_url = f'/static/uploads/{filename}'
            
            producto = Articulo(
                codigo=request.form['codigo'],
                nombre_breve=request.form['nombre_breve'],
                descripcion=request.form['descripcion'],
                costo=float(request.form['costo']) if request.form['costo'] else 0.0,
                precio=float(request.form['precio']) if request.form['precio'] else 0.0,
                id_categoria=int(request.form['id_categoria']),
                id_proveedor=int(request.form['id_proveedor']) if request.form['id_proveedor'] else None,
                stock_actual=int(request.form['stock_actual']) if request.form['stock_actual'] else 0,
                stock_minimo=int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0,
                imagen_url=imagen_url
            )
            
            db.session.add(producto)
            db.session.commit()
            flash('¡Producto agregado exitosamente!', 'success')
            return redirect(url_for('inventario'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('agregar_producto.html', categorias=categorias, proveedores=proveedores)

@app.route('/producto/editar/<int:id>', methods=['GET', 'POST'])
@permiso_required('editar_producto')
def editar_producto(id):
    """
    Editar un producto existente
    """
    producto = Articulo.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            # Procesar imagen si se subió
            if 'imagen' in request.files:
                file = request.files['imagen']
                if file and file.filename and allowed_file(file.filename):
                    # Eliminar imagen anterior si existe
                    if producto.imagen_url:
                        old_path = os.path.join(app.root_path, producto.imagen_url.lstrip('/'))
                        if os.path.exists(old_path):
                            os.remove(old_path)
                    
                    filename = secure_filename(file.filename)
                    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S_')
                    filename = timestamp + filename
                    upload_path = os.path.join(app.root_path, 'static', 'uploads')
                    os.makedirs(upload_path, exist_ok=True)
                    filepath = os.path.join(upload_path, filename)
                    file.save(filepath)
                    producto.imagen_url = f'/static/uploads/{filename}'
            
            producto.codigo = request.form['codigo']
            producto.nombre_breve = request.form['nombre_breve']
            producto.descripcion = request.form['descripcion']
            producto.costo = float(request.form['costo']) if request.form['costo'] else 0.0
            producto.precio = float(request.form['precio']) if request.form['precio'] else 0.0
            producto.id_categoria = int(request.form['id_categoria'])
            producto.id_proveedor = int(request.form['id_proveedor']) if request.form['id_proveedor'] else None
            producto.stock_actual = int(request.form['stock_actual']) if request.form['stock_actual'] else 0
            producto.stock_minimo = int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0
            
            db.session.commit()
            flash('¡Producto actualizado exitosamente!', 'success')
            return redirect(url_for('inventario'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('editar_producto.html', producto=producto, categorias=categorias, proveedores=proveedores)

@app.route('/producto/eliminar/<int:id>', methods=['POST'])
@permiso_required('eliminar_producto')
def eliminar_producto(id):
    """
    Eliminar un producto (marcar como inactivo)
    """
    try:
        producto = Articulo.query.get_or_404(id)
        producto.activo = False
        db.session.commit()
        flash('¡Producto eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el producto: {str(e)}', 'error')
    
    return redirect(url_for('inventario'))

@app.route('/producto/ver/<int:id>')
@permiso_required('ver_producto')
def ver_producto(id):
    """
    Ver detalles de un producto
    """
    producto = Articulo.query.get_or_404(id)
    return render_template('ver_producto.html', producto=producto)

@app.route('/api/productos')
@permiso_required('api_productos')
def api_productos():
    """
    API endpoint para obtener todos los productos activos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    productos_json = []
    
    for producto in productos:
        productos_json.append({
            'id': producto.id_articulo,
            'codigo': producto.codigo,
            'nombre_breve': producto.nombre_breve,
            'descripcion': producto.descripcion,
            'costo': producto.costo,
            'precio': producto.precio,
            'stock_actual': producto.stock_actual,
            'stock_minimo': producto.stock_minimo,
            'categoria': producto.categoria.nombre_categoria if producto.categoria else 'Sin categoría',
            'proveedor': producto.proveedor.nombre_proveedor if producto.proveedor else 'Sin proveedor',
            'imagen_url': producto.imagen_url if producto.imagen_url else None
        })
    
    return jsonify(productos_json)

@app.route('/stock-bajo')
@permiso_required('stock_bajo')
def stock_bajo():
    """
    Mostrar productos con stock bajo
    """
    productos_bajo_stock = Articulo.query.filter(
        Articulo.stock_actual <= Articulo.stock_minimo,
        Articulo.activo == True
    ).all()
    
    # Calcular estadísticas específicas
    stock_negativo_count = len([p for p in productos_bajo_stock if p.stock_actual < 0])
    stock_cero_count = len([p for p in productos_bajo_stock if p.stock_actual == 0])
    valor_total_alertas = sum(p.precio for p in productos_bajo_stock)
    
    return render_template('stock_bajo.html', 
                         productos=productos_bajo_stock,
                         stock_negativo_count=stock_negativo_count,
                         stock_cero_count=stock_cero_count,
                         valor_total_alertas=valor_total_alertas)

# Categorías CRUD
@app.route('/categorias')
@permiso_required('categorias')
def categorias():
    """
    Mostrar todas las categorías
    """
    categorias = Categoria.query.filter_by(activo=True).all()
    return render_template('categorias.html', categorias=categorias)

@app.route('/categoria/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_categoria')
def agregar_categoria():
    """
    Agregar una nueva categoría
    """
    if request.method == 'POST':
        try:
            categoria = Categoria(
                nombre_categoria=request.form['nombre_categoria'],
                descripcion=request.form['descripcion']
            )
            
            db.session.add(categoria)
            db.session.commit()
            flash('¡Categoría agregada exitosamente!', 'success')
            return redirect(url_for('categorias'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar la categoría: {str(e)}', 'error')
    
    return render_template('agregar_categoria.html')

@app.route('/proveedores')
@permiso_required('proveedores')
def proveedores():
    """
    Mostrar todos los proveedores
    """
    proveedores = Proveedor.query.filter_by(activo=True).all()
    
    # Calcular estadísticas de proveedores
    proveedores_con_email = len([p for p in proveedores if p.email])
    proveedores_con_telefono = len([p for p in proveedores if p.telefono])
    
    return render_template('proveedores.html', 
                         proveedores=proveedores,
                         proveedores_con_email=proveedores_con_email,
                         proveedores_con_telefono=proveedores_con_telefono)

@app.route('/proveedor/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_proveedor')
def agregar_proveedor():
    """
    Agregar un nuevo proveedor
    """
    if request.method == 'POST':
        try:
            proveedor = Proveedor(
                nombre_proveedor=request.form['nombre_proveedor'],
                contacto=request.form['contacto'] if request.form['contacto'] else None,
                telefono=request.form['telefono'] if request.form['telefono'] else None,
                email=request.form['email'] if request.form['email'] else None,
                direccion=request.form['direccion'] if request.form['direccion'] else None
            )
            
            db.session.add(proveedor)
            db.session.commit()
            flash('¡Proveedor agregado exitosamente!', 'success')
            return redirect(url_for('proveedores'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el proveedor: {str(e)}', 'error')
    
    return render_template('agregar_proveedor.html')

# =====================================================
# RUTAS DE GESTIÓN DE CLIENTES
# =====================================================

@app.route('/clientes')
@permiso_required('clientes')
def clientes():
    """
    Mostrar todos los clientes
    """
    clientes = Cliente.query.filter_by(activo=True).all()
    return render_template('clientes.html', clientes=clientes)

@app.route('/cliente/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_cliente')
def agregar_cliente():
    """
    Agregar un nuevo cliente
    """
    if request.method == 'POST':
        try:
            # Verificar DNI único
            if Cliente.query.filter_by(dni=request.form['dni']).first():
                flash('El DNI ya está registrado', 'error')
                return render_template('agregar_cliente.html')
            
            # Verificar email único si se proporciona
            if request.form.get('email'):
                if Cliente.query.filter_by(email=request.form['email']).first():
                    flash('El email ya está registrado', 'error')
                    return render_template('agregar_cliente.html')
            
            cliente = Cliente(
                nombre=request.form['nombre'],
                apellido=request.form['apellido'],
                dni=request.form['dni'],
                direccion=request.form['direccion'] if request.form['direccion'] else None,
                email=request.form['email'] if request.form['email'] else None,
                celular=request.form['celular'] if request.form['celular'] else None
            )
            
            db.session.add(cliente)
            db.session.commit()
            flash('¡Cliente agregado exitosamente!', 'success')
            return redirect(url_for('clientes'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el cliente: {str(e)}', 'error')
    
    return render_template('agregar_cliente.html')

@app.route('/cliente/editar/<int:id>', methods=['GET', 'POST'])
@permiso_required('editar_cliente')
def editar_cliente(id):
    """
    Editar un cliente existente
    """
    cliente = Cliente.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            # Verificar DNI único (excepto el cliente actual)
            dni_existente = Cliente.query.filter(
                Cliente.dni == request.form['dni'],
                Cliente.id_cliente != id
            ).first()
            if dni_existente:
                flash('El DNI ya está registrado por otro cliente', 'error')
                return render_template('editar_cliente.html', cliente=cliente)
            
            # Verificar email único (excepto el cliente actual)
            if request.form.get('email'):
                email_existente = Cliente.query.filter(
                    Cliente.email == request.form['email'],
                    Cliente.id_cliente != id
                ).first()
                if email_existente:
                    flash('El email ya está registrado por otro cliente', 'error')
                    return render_template('editar_cliente.html', cliente=cliente)
            
            cliente.nombre = request.form['nombre']
            cliente.apellido = request.form['apellido']
            cliente.dni = request.form['dni']
            cliente.direccion = request.form['direccion'] if request.form['direccion'] else None
            cliente.email = request.form['email'] if request.form['email'] else None
            cliente.celular = request.form['celular'] if request.form['celular'] else None
            
            db.session.commit()
            flash('¡Cliente actualizado exitosamente!', 'success')
            return redirect(url_for('clientes'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el cliente: {str(e)}', 'error')
    
    return render_template('editar_cliente.html', cliente=cliente)

@app.route('/cliente/eliminar/<int:id>', methods=['POST'])
@permiso_required('eliminar_cliente')
def eliminar_cliente(id):
    """
    Eliminar un cliente (marcar como inactivo)
    """
    try:
        cliente = Cliente.query.get_or_404(id)
        cliente.activo = False
        db.session.commit()
        flash('¡Cliente eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el cliente: {str(e)}', 'error')
    
    return redirect(url_for('clientes'))

@app.route('/cliente/ver/<int:id>')
@permiso_required('ver_cliente')
def ver_cliente(id):
    """
    Ver detalles de un cliente
    """
    cliente = Cliente.query.get_or_404(id)
    ordenes = OrdenVenta.query.filter_by(id_cliente=id).order_by(OrdenVenta.fecha_orden.desc()).limit(10).all()
    return render_template('ver_cliente.html', cliente=cliente, ordenes=ordenes)

# =====================================================
# RUTAS DEL PROCESO DE VENTA
# =====================================================

@app.route('/ventas')
@permiso_required('ventas')
def ventas():
    """
    Catálogo de productos para venta
    """
    productos = Articulo.query.filter_by(activo=True).all()
    categorias = Categoria.query.filter_by(activo=True).all()
    clientes = Cliente.query.filter_by(activo=True).all()
    
    return render_template('ventas.html', 
                         productos=productos,
                         categorias=categorias,
                         clientes=clientes)

@app.route('/api/productos-venta')
@permiso_required('ventas')
def api_productos_venta():
    """
    API endpoint para obtener productos disponibles para venta
    """
    productos = Articulo.query.filter_by(activo=True).all()
    productos_json = []
    
    for producto in productos:
        productos_json.append({
            'id': producto.id_articulo,
            'codigo': producto.codigo,
            'nombre_breve': producto.nombre_breve,
            'descripcion': producto.descripcion,
            'precio': producto.precio,
            'stock_actual': producto.stock_actual,
            'categoria': producto.categoria.nombre_categoria if producto.categoria else 'Sin categoría',
            'imagen_url': producto.imagen_url if producto.imagen_url else None
        })
    
    return jsonify(productos_json)

@app.route('/carrito/agregar', methods=['POST'])
@permiso_required('ventas')
def agregar_al_carrito():
    """
    Agregar producto al carrito
    """
    data = request.get_json()
    producto_id = data.get('producto_id')
    cantidad = int(data.get('cantidad', 1))
    
    producto = Articulo.query.get_or_404(producto_id)
    
    # Validar stock
    if cantidad > producto.stock_actual:
        return jsonify({'success': False, 'message': f'Stock insuficiente. Disponible: {producto.stock_actual}'}), 400
    
    if cantidad <= 0:
        return jsonify({'success': False, 'message': 'La cantidad debe ser mayor a 0'}), 400
    
    # Inicializar carrito si no existe
    if 'carrito' not in session:
        session['carrito'] = []
    
    # Buscar si el producto ya está en el carrito
    carrito = session['carrito']
    producto_en_carrito = next((item for item in carrito if item['id'] == producto_id), None)
    
    if producto_en_carrito:
        nueva_cantidad = producto_en_carrito['cantidad'] + cantidad
        if nueva_cantidad > producto.stock_actual:
            return jsonify({'success': False, 'message': f'Stock insuficiente. Disponible: {producto.stock_actual}, ya en carrito: {producto_en_carrito["cantidad"]}'}), 400
        producto_en_carrito['cantidad'] = nueva_cantidad
        producto_en_carrito['subtotal'] = nueva_cantidad * producto.precio
    else:
        carrito.append({
            'id': producto_id,
            'codigo': producto.codigo,
            'nombre': producto.nombre_breve,
            'precio': float(producto.precio),
            'cantidad': cantidad,
            'stock_actual': producto.stock_actual,
            'subtotal': cantidad * producto.precio,
            'imagen_url': producto.imagen_url if producto.imagen_url else None
        })
    
    session['carrito'] = carrito
    session.modified = True
    
    return jsonify({'success': True, 'message': 'Producto agregado al carrito', 'carrito': carrito})

@app.route('/carrito/actualizar', methods=['POST'])
@permiso_required('ventas')
def actualizar_carrito():
    """
    Actualizar cantidad de un producto en el carrito
    """
    data = request.get_json()
    producto_id = data.get('producto_id')
    nueva_cantidad = int(data.get('cantidad', 1))
    
    if 'carrito' not in session or not session['carrito']:
        return jsonify({'success': False, 'message': 'Carrito vacío'}), 400
    
    carrito = session['carrito']
    producto_en_carrito = next((item for item in carrito if item['id'] == producto_id), None)
    
    if not producto_en_carrito:
        return jsonify({'success': False, 'message': 'Producto no encontrado en el carrito'}), 404
    
    producto = Articulo.query.get_or_404(producto_id)
    
    if nueva_cantidad <= 0:
        # Eliminar del carrito si cantidad es 0
        carrito.remove(producto_en_carrito)
    elif nueva_cantidad > producto.stock_actual:
        return jsonify({'success': False, 'message': f'Stock insuficiente. Disponible: {producto.stock_actual}'}), 400
    else:
        producto_en_carrito['cantidad'] = nueva_cantidad
        producto_en_carrito['subtotal'] = nueva_cantidad * producto.precio
    
    session['carrito'] = carrito
    session.modified = True
    
    return jsonify({'success': True, 'message': 'Carrito actualizado', 'carrito': carrito})

@app.route('/carrito/eliminar/<int:producto_id>', methods=['POST'])
@permiso_required('ventas')
def eliminar_del_carrito(producto_id):
    """
    Eliminar producto del carrito
    """
    if 'carrito' not in session or not session['carrito']:
        return jsonify({'success': False, 'message': 'Carrito vacío'}), 400
    
    carrito = session['carrito']
    carrito = [item for item in carrito if item['id'] != producto_id]
    
    session['carrito'] = carrito
    session.modified = True
    
    return jsonify({'success': True, 'message': 'Producto eliminado del carrito', 'carrito': carrito})

@app.route('/carrito')
@permiso_required('ventas')
def ver_carrito():
    """
    Ver carrito de compras
    """
    carrito = session.get('carrito', [])
    clientes = Cliente.query.filter_by(activo=True).all()
    
    # Calcular totales
    subtotal = sum(item['subtotal'] for item in carrito)
    impuestos = subtotal * 0.21  # IVA 21%
    total = subtotal + impuestos
    
    return render_template('carrito.html', 
                         carrito=carrito,
                         subtotal=subtotal,
                         impuestos=impuestos,
                         total=total,
                         clientes=clientes)

@app.route('/venta/confirmar', methods=['POST'])
@permiso_required('procesar_venta')
def confirmar_venta():
    """
    Confirmar y procesar la venta
    """
    if 'carrito' not in session or not session['carrito']:
        flash('El carrito está vacío', 'error')
        return redirect(url_for('ventas'))
    
    try:
        id_cliente = int(request.form['id_cliente'])
        direccion_entrega = request.form['direccion_entrega']
        observaciones = request.form.get('observaciones', '')
        
        cliente = Cliente.query.get_or_404(id_cliente)
        carrito = session['carrito']
        
        # Validar stock de todos los productos antes de procesar
        productos_insuficientes = []
        for item in carrito:
            producto = Articulo.query.get(item['id'])
            if producto.stock_actual < item['cantidad']:
                productos_insuficientes.append({
                    'nombre': producto.nombre_breve,
                    'solicitado': item['cantidad'],
                    'disponible': producto.stock_actual
                })
        
        if productos_insuficientes:
            mensaje = 'Stock insuficiente para los siguientes productos:\n'
            for prod in productos_insuficientes:
                mensaje += f"- {prod['nombre']}: solicitado {prod['solicitado']}, disponible {prod['disponible']}\n"
            flash(mensaje, 'error')
            return redirect(url_for('ver_carrito'))
        
        # Calcular totales
        subtotal = sum(item['subtotal'] for item in carrito)
        impuestos = subtotal * 0.21
        total = subtotal + impuestos
        
        # Generar número de orden
        fecha_actual = datetime.now()
        numero_orden = f"ORD-{fecha_actual.strftime('%Y%m%d')}-{OrdenVenta.query.count() + 1:04d}"
        
        # Crear orden de venta
        orden = OrdenVenta(
            numero_orden=numero_orden,
            id_cliente=id_cliente,
            id_usuario_vendedor=session['user_id'],
            subtotal=subtotal,
            impuestos=impuestos,
            total=total,
            direccion_entrega=direccion_entrega,
            observaciones=observaciones,
            estado='CONFIRMADA'
        )
        
        db.session.add(orden)
        db.session.flush()  # Para obtener el ID de la orden
        
        # Crear detalles y actualizar stock
        for item in carrito:
            producto = Articulo.query.get(item['id'])
            
            # Crear detalle
            detalle = DetalleOrden(
                id_orden=orden.id_orden,
                id_articulo=item['id'],
                cantidad=item['cantidad'],
                precio_unitario=item['precio'],
                subtotal=item['subtotal']
            )
            db.session.add(detalle)
            
            # Actualizar stock
            producto.stock_actual -= item['cantidad']
        
        db.session.commit()
        
        # Limpiar carrito
        session['carrito'] = []
        session.modified = True
        
        flash(f'¡Venta confirmada exitosamente! Orden: {numero_orden}', 'success')
        return redirect(url_for('ver_orden', id=orden.id_orden))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error al procesar la venta: {str(e)}', 'error')
        return redirect(url_for('ver_carrito'))

@app.route('/orden/ver/<int:id>')
@permiso_required('ventas')
def ver_orden(id):
    """
    Ver detalles de una orden de venta
    """
    orden = OrdenVenta.query.get_or_404(id)
    return render_template('ver_orden.html', orden=orden)

@app.route('/carrito/limpiar', methods=['POST'])
@permiso_required('ventas')
def limpiar_carrito():
    """
    Limpiar el carrito completamente
    """
    session['carrito'] = []
    session.modified = True
    flash('Carrito limpiado', 'info')
    return redirect(url_for('ventas'))

# =====================================================
# RUTAS DE GESTIÓN DE ÓRDENES DE COMPRA
# =====================================================

@app.route('/ordenes-compra')
@permiso_required('ordenes_compra')
def ordenes_compra():
    """
    Mostrar todas las órdenes de compra
    """
    ordenes = OrdenCompra.query.order_by(OrdenCompra.fecha_orden.desc()).all()
    return render_template('ordenes_compra.html', ordenes=ordenes)

@app.route('/orden-compra/nueva', methods=['GET', 'POST'])
@permiso_required('generar_compra')
def nueva_orden_compra():
    """
    Crear una nueva orden de compra
    """
    if request.method == 'POST':
        try:
            proveedor = Proveedor.query.get_or_404(int(request.form['id_proveedor']))
            productos_seleccionados = request.form.getlist('productos')
            cantidades = request.form.getlist('cantidades')
            precios = request.form.getlist('precios')
            
            if not productos_seleccionados:
                flash('Debe seleccionar al menos un producto', 'error')
                return redirect(url_for('nueva_orden_compra'))
            
            # Calcular totales
            subtotal = 0
            detalles = []
            for i, producto_id in enumerate(productos_seleccionados):
                cantidad = int(cantidades[i])
                precio = float(precios[i])
                subtotal += cantidad * precio
                detalles.append({
                    'id_articulo': int(producto_id),
                    'cantidad': cantidad,
                    'precio': precio
                })
            
            impuestos = subtotal * 0.21
            total = subtotal + impuestos
            
            # Generar número de orden
            fecha_actual = datetime.now()
            numero_orden = f"OC-{fecha_actual.strftime('%Y%m%d')}-{OrdenCompra.query.count() + 1:04d}"
            
            # Crear orden de compra
            orden = OrdenCompra(
                numero_orden=numero_orden,
                id_proveedor=proveedor.id_proveedor,
                id_usuario_comprador=session['user_id'],
                subtotal=subtotal,
                impuestos=impuestos,
                total=total,
                observaciones=request.form.get('observaciones', ''),
                estado='PENDIENTE'
            )
            
            db.session.add(orden)
            db.session.flush()
            
            # Crear detalles
            for detalle in detalles:
                detalle_orden = DetalleOrdenCompra(
                    id_orden_compra=orden.id_orden_compra,
                    id_articulo=detalle['id_articulo'],
                    cantidad=detalle['cantidad'],
                    precio_unitario=detalle['precio'],
                    subtotal=detalle['cantidad'] * detalle['precio']
                )
                db.session.add(detalle_orden)
            
            db.session.commit()
            flash(f'¡Orden de compra creada exitosamente! Número: {numero_orden}', 'success')
            return redirect(url_for('ver_orden_compra', id=orden.id_orden_compra))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear la orden de compra: {str(e)}', 'error')
    
    proveedores = Proveedor.query.filter_by(activo=True).all()
    productos = Articulo.query.filter_by(activo=True).all()
    return render_template('nueva_orden_compra.html', proveedores=proveedores, productos=productos)

@app.route('/orden-compra/ver/<int:id>')
@permiso_required('ordenes_compra')
def ver_orden_compra(id):
    """
    Ver detalles de una orden de compra
    """
    orden = OrdenCompra.query.get_or_404(id)
    return render_template('ver_orden_compra.html', orden=orden)

@app.route('/orden-compra/recibir/<int:id>', methods=['POST'])
@permiso_required('ordenes_compra')
def recibir_orden_compra(id):
    """
    Marcar orden de compra como recibida y actualizar stock
    """
    try:
        orden = OrdenCompra.query.get_or_404(id)
        
        if orden.estado != 'CONFIRMADA':
            flash('Solo se pueden recibir órdenes confirmadas', 'error')
            return redirect(url_for('ver_orden_compra', id=id))
        
        # Actualizar stock de cada producto
        for detalle in orden.detalles:
            producto = Articulo.query.get(detalle.id_articulo)
            producto.stock_actual += detalle.cantidad
        
        orden.estado = 'RECIBIDA'
        db.session.commit()
        
        flash('¡Orden de compra recibida y stock actualizado exitosamente!', 'success')
        return redirect(url_for('ver_orden_compra', id=id))
        
    except Exception as e:
        db.session.rollback()
        flash(f'Error al recibir la orden: {str(e)}', 'error')
        return redirect(url_for('ver_orden_compra', id=id))

@app.route('/orden-compra/confirmar/<int:id>', methods=['POST'])
@permiso_required('ordenes_compra')
def confirmar_orden_compra(id):
    """
    Confirmar una orden de compra
    """
    try:
        orden = OrdenCompra.query.get_or_404(id)
        orden.estado = 'CONFIRMADA'
        db.session.commit()
        flash('Orden de compra confirmada', 'success')
        return redirect(url_for('ver_orden_compra', id=id))
    except Exception as e:
        db.session.rollback()
        flash(f'Error al confirmar la orden: {str(e)}', 'error')
        return redirect(url_for('ver_orden_compra', id=id))

@app.route('/generar-compra/<int:id_articulo>', methods=['GET', 'POST'])
@permiso_required('generar_compra')
def generar_compra(id_articulo):
    """
    Generar orden de compra rápida para un producto desde inventario
    """
    producto = Articulo.query.get_or_404(id_articulo)
    
    if request.method == 'POST':
        try:
            proveedor = Proveedor.query.get_or_404(int(request.form['id_proveedor']))
            cantidad = int(request.form['cantidad'])
            precio_unitario = float(request.form['precio_unitario'])
            
            subtotal = cantidad * precio_unitario
            impuestos = subtotal * 0.21
            total = subtotal + impuestos
            
            # Generar número de orden
            fecha_actual = datetime.now()
            numero_orden = f"OC-{fecha_actual.strftime('%Y%m%d')}-{OrdenCompra.query.count() + 1:04d}"
            
            # Crear orden de compra
            orden = OrdenCompra(
                numero_orden=numero_orden,
                id_proveedor=proveedor.id_proveedor,
                id_usuario_comprador=session['user_id'],
                subtotal=subtotal,
                impuestos=impuestos,
                total=total,
                observaciones=f'Compra rápida de {producto.nombre_breve}',
                estado='PENDIENTE'
            )
            
            db.session.add(orden)
            db.session.flush()
            
            # Crear detalle
            detalle = DetalleOrdenCompra(
                id_orden_compra=orden.id_orden_compra,
                id_articulo=producto.id_articulo,
                cantidad=cantidad,
                precio_unitario=precio_unitario,
                subtotal=subtotal
            )
            db.session.add(detalle)
            db.session.commit()
            
            flash(f'¡Orden de compra creada exitosamente! Número: {numero_orden}', 'success')
            return redirect(url_for('ver_orden_compra', id=orden.id_orden_compra))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al crear la orden de compra: {str(e)}', 'error')
    
    proveedores = Proveedor.query.filter_by(activo=True).all()
    # Si el producto tiene proveedor, preseleccionarlo
    proveedor_actual = producto.proveedor if producto.proveedor else None
    
    return render_template('generar_compra.html', 
                         producto=producto, 
                         proveedores=proveedores,
                         proveedor_actual=proveedor_actual)

def inicializar_datos():
    """
    Inicializar la base de datos con datos de ejemplo
    """
    # Inicializar usuario administrador por defecto
    if not Usuario.query.first():
        print("Inicializando usuario administrador...")
        admin = Usuario(
            nombre_apellido='Administrador del Sistema',
            email='admin@sistema.com',
            dni='12345678',
            calle='Av. Principal',
            numero='123',
            codigo_postal='1000',
            rol='administrador'
        )
        admin.establecer_contraseña('Admin123!')
        db.session.add(admin)
        db.session.commit()
        print("Usuario administrador creado: admin@sistema.com / Admin123!")
    
    if not Categoria.query.first():
        print("Inicializando categorías...")
        categorias_ejemplo = [
            Categoria(nombre_categoria='Linea Estandar', descripcion='Productos de línea estándar con características básicas'),
            Categoria(nombre_categoria='Linea Media', descripcion='Productos de línea media con características intermedias'),
            Categoria(nombre_categoria='Linea Premium', descripcion='Productos de línea premium con características avanzadas')
        ]
        
        for cat in categorias_ejemplo:
            db.session.add(cat)
        
        db.session.commit()
    
    if not Proveedor.query.first():
        print("Inicializando proveedores...")
        proveedores_ejemplo = [
            Proveedor(
                nombre_proveedor='Proveedor ABC S.A.',
                contacto='Juan Pérez',
                telefono='011-1234-5678',
                email='contacto@proveedorabc.com',
                direccion='Av. Corrientes 1234, CABA'
            ),
            Proveedor(
                nombre_proveedor='Distribuidora XYZ',
                contacto='María González',
                telefono='011-9876-5432',
                email='ventas@distribuidoraxyz.com',
                direccion='Av. Santa Fe 5678, CABA'
            ),
            Proveedor(
                nombre_proveedor='Importadora DEF',
                contacto='Carlos López',
                telefono='011-5555-1234',
                email='info@importadoradef.com',
                direccion='Av. Rivadavia 9012, CABA'
            )
        ]
        
        for prov in proveedores_ejemplo:
            db.session.add(prov)
        
        db.session.commit()
    
    if not Articulo.query.first():
        print("Inicializando artículos de ejemplo...")
        articulos_ejemplo = [
            Articulo(
                codigo='ART001',
                nombre_breve='Laptop HP 15',
                descripcion='Laptop HP Pavilion 15 pulgadas, Intel i5, 8GB RAM, 256GB SSD',
                costo=450.00,
                precio=650.00,
                id_categoria=1,  # Linea Media
                id_proveedor=1,
                stock_actual=10,
                stock_minimo=2
            ),
            Articulo(
                codigo='ART002',
                nombre_breve='Mouse Inalámbrico',
                descripcion='Mouse óptico inalámbrico Logitech M705',
                costo=25.00,
                precio=45.00,
                id_categoria=1,  # Linea Estandar
                id_proveedor=2,
                stock_actual=50,
                stock_minimo=10
            ),
            Articulo(
                codigo='ART003',
                nombre_breve='Teclado Mecánico',
                descripcion='Teclado mecánico RGB Corsair K70',
                costo=80.00,
                precio=120.00,
                id_categoria=3,  # Linea Premium
                id_proveedor=1,
                stock_actual=15,
                stock_minimo=5
            ),
            Articulo(
                codigo='ART004',
                nombre_breve='Monitor 24"',
                descripcion='Monitor LED 24 pulgadas Full HD Samsung',
                costo=180.00,
                precio=280.00,
                id_categoria=2,  # Linea Media
                id_proveedor=3,
                stock_actual=8,
                stock_minimo=3
            )
        ]
        
        for art in articulos_ejemplo:
            db.session.add(art)
        
        db.session.commit()
        print("¡Base de datos inicializada exitosamente!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        inicializar_datos()
    
    app.run(debug=True, host='0.0.0.0', port=5000)

