from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import os
import re
import hashlib
from functools import wraps
import secrets
import string

# Configuración de la aplicación Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'tu_clave_secreta_aqui_2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///productos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar SQLAlchemy
db = SQLAlchemy(app)

# Modelo para cada tabla de la base de datos
class Categoria(db.Model):
    __tablename__ = 'categorias'
    id_categoria = db.Column(db.Integer, primary_key=True)
    nombre_categoria = db.Column(db.String(100), unique=True, nullable=False)
    descripcion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Categoria {self.nombre_categoria}>'

class Proveedor(db.Model):
    __tablename__ = 'proveedores'
    id_proveedor = db.Column(db.Integer, primary_key=True)
    nombre_proveedor = db.Column(db.String(100), nullable=False)
    contacto = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Proveedor {self.nombre_proveedor}>'

class Articulo(db.Model):
    __tablename__ = 'articulos'
    id_articulo = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), unique=True, nullable=False)
    nombre_breve = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    costo = db.Column(db.Float, nullable=False, default=0.0)
    precio = db.Column(db.Float, nullable=False, default=0.0)
    id_proveedor = db.Column(db.Integer, db.ForeignKey('proveedores.id_proveedor'))
    id_categoria = db.Column(db.Integer, db.ForeignKey('categorias.id_categoria'), nullable=False)
    stock_actual = db.Column(db.Integer, default=0)
    stock_minimo = db.Column(db.Integer, default=0)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    # Relaciones
    categoria = db.relationship('Categoria', backref='articulos')
    proveedor = db.relationship('Proveedor', backref='articulos')
    
    def __repr__(self):
        return f'<Articulo {self.nombre_breve}>'

class Usuario(db.Model):
    __tablename__ = 'usuarios'
    id = db.Column(db.Integer, primary_key=True)
    nombre_apellido = db.Column(db.String(200), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    dni = db.Column(db.String(20), unique=True, nullable=False)
    calle = db.Column(db.String(200), nullable=False)
    numero = db.Column(db.String(20), nullable=False)
    codigo_postal = db.Column(db.String(20), nullable=False)
    rol = db.Column(db.String(50), nullable=False)  # administrador, analista, gerente
    estado = db.Column(db.String(20), default='activo')  # activo, inactivo
    contraseña_hash = db.Column(db.String(255), nullable=False)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    ultimo_acceso = db.Column(db.DateTime)
    
    def __repr__(self):
        return f'<Usuario {self.nombre_apellido}>'
    
    def verificar_contraseña(self, contraseña):
        """Verificar contraseña usando hash SHA-256"""
        return hashlib.sha256(contraseña.encode()).hexdigest() == self.contraseña_hash
    
    def establecer_contraseña(self, contraseña):
        """Establecer contraseña con hash SHA-256"""
        self.contraseña_hash = hashlib.sha256(contraseña.encode()).hexdigest()

# Funciones de validación
def validar_contraseña(contraseña):
    """
    Validar contraseña según los requisitos:
    - Mínimo 8 caracteres, máximo 16
    - Al menos un símbolo
    - Al menos un número
    - Al menos una mayúscula
    - Al menos una minúscula
    """
    if len(contraseña) < 8 or len(contraseña) > 16:
        return False, "La contraseña debe tener entre 8 y 16 caracteres"
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', contraseña):
        return False, "La contraseña debe contener al menos un símbolo"
    
    if not re.search(r'\d', contraseña):
        return False, "La contraseña debe contener al menos un número"
    
    if not re.search(r'[A-Z]', contraseña):
        return False, "La contraseña debe contener al menos una mayúscula"
    
    if not re.search(r'[a-z]', contraseña):
        return False, "La contraseña debe contener al menos una minúscula"
    
    return True, "Contraseña válida"

def login_required(f):
    """Decorador para requerir autenticación"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', 'error')
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated_function

def admin_required(f):
    """Decorador para requerir rol de administrador"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            flash('Debes iniciar sesión para acceder a esta página', 'error')
            return redirect(url_for('login'))
        
        user = Usuario.query.get(session['user_id'])
        if not user or user.rol != 'administrador':
            flash('No tienes permisos para acceder a esta página', 'error')
            return redirect(url_for('index'))
        
        return f(*args, **kwargs)
    return decorated_function

# Sistema de permisos por rol
PERMISOS_POR_ROL = {
    'administrador': {
        'inicio': True,
        'productos': True,
        'categorias': True,
        'proveedores': True,
        'stock_bajo': True,
        'usuarios': True,
        'agregar_producto': True,
        'editar_producto': True,
        'eliminar_producto': True,
        'ver_producto': True,
        'agregar_categoria': True,
        'agregar_proveedor': True,
        'api_productos': True
    },
    'gerente': {
        'inicio': True,
        'productos': True,
        'categorias': True,
        'proveedores': True,
        'stock_bajo': True,
        'usuarios': False,
        'agregar_producto': True,
        'editar_producto': True,
        'eliminar_producto': True,
        'ver_producto': True,
        'agregar_categoria': True,
        'agregar_proveedor': True,
        'api_productos': True
    },
    'analista': {
        'inicio': True,
        'productos': False,
        'categorias': False,
        'proveedores': False,
        'stock_bajo': True,
        'usuarios': False,
        'agregar_producto': False,
        'editar_producto': False,
        'eliminar_producto': False,
        'ver_producto': False,
        'agregar_categoria': False,
        'agregar_proveedor': False,
        'api_productos': False
    }
}

def verificar_permiso(permiso):
    """Verificar si el usuario actual tiene un permiso específico"""
    if 'user_role' not in session:
        return False
    
    rol = session['user_role']
    return PERMISOS_POR_ROL.get(rol, {}).get(permiso, False)

def permiso_required(permiso):
    """Decorador para requerir un permiso específico"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                flash('Debes iniciar sesión para acceder a esta página', 'error')
                return redirect(url_for('login'))
            
            # Verificar si la sesión ha expirado
            if 'last_activity' in session:
                last_activity = datetime.fromisoformat(session['last_activity'])
                if datetime.now() - last_activity > timedelta(minutes=10):
                    session.clear()
                    flash('Tu sesión ha expirado. Por favor, inicia sesión nuevamente', 'warning')
                    return redirect(url_for('login'))
            
            # Actualizar última actividad
            session['last_activity'] = datetime.now().isoformat()
            
            if not verificar_permiso(permiso):
                flash('No tienes permisos para acceder a esta página', 'error')
                return redirect(url_for('index'))
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

def generar_token_recuperacion():
    """Generar token seguro para recuperación de contraseña"""
    return ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(32))

def verificar_sesion_activa():
    """Verificar si la sesión está activa y no ha expirado"""
    if 'user_id' not in session:
        return False
    
    if 'last_activity' in session:
        last_activity = datetime.fromisoformat(session['last_activity'])
        if datetime.now() - last_activity > timedelta(minutes=10):
            session.clear()
            return False
    
    return True

# Rutas de autenticación
@app.route('/login', methods=['GET', 'POST'])
def login():
    """
    Página de inicio de sesión con validaciones mejoradas
    """
    # Si ya está logueado, redirigir según su rol
    if verificar_sesion_activa():
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form['email']
        contraseña = request.form['contraseña']
        
        # Buscar usuario por email
        usuario = Usuario.query.filter_by(email=email).first()
        
        if not usuario:
            flash('Usuario y/o contraseña incorrecta', 'error')
            return render_template('login.html')
        
        # Verificar si el usuario está activo
        if usuario.estado != 'activo':
            flash('Tu cuenta está inactiva. Contacta al administrador', 'error')
            return render_template('login.html')
        
        # Verificar contraseña
        if not usuario.verificar_contraseña(contraseña):
            flash('Usuario y/o contraseña incorrecta', 'error')
            return render_template('login.html')
        
        # Login exitoso
        session['user_id'] = usuario.id
        session['user_name'] = usuario.nombre_apellido
        session['user_role'] = usuario.rol
        session['last_activity'] = datetime.now().isoformat()
        
        # Actualizar último acceso
        usuario.ultimo_acceso = datetime.utcnow()
        db.session.commit()
        
        flash(f'¡Bienvenido, {usuario.nombre_apellido}!', 'success')
        return redirect(url_for('index'))
    
    return render_template('login.html')

@app.route('/logout')
def logout():
    """
    Cerrar sesión
    """
    session.clear()
    flash('Has cerrado sesión exitosamente', 'info')
    return redirect(url_for('login'))

@app.route('/recuperar-contraseña', methods=['GET', 'POST'])
def recuperar_contraseña():
    """
    Proceso de recuperación de contraseña
    """
    if request.method == 'POST':
        email = request.form['email']
        usuario = Usuario.query.filter_by(email=email, estado='activo').first()
        
        if usuario:
            # Generar nueva contraseña temporal
            nueva_contraseña = ''.join(secrets.choice(string.ascii_letters + string.digits) for _ in range(12))
            usuario.establecer_contraseña(nueva_contraseña)
            db.session.commit()
            
            flash(f'Se ha generado una nueva contraseña temporal: {nueva_contraseña}. Por favor, cámbiala después del primer login.', 'success')
            return redirect(url_for('login'))
        else:
            flash('No se encontró un usuario activo con ese email', 'error')
    
    return render_template('recuperar_contraseña.html')

@app.route('/cambiar-contraseña', methods=['GET', 'POST'])
@login_required
def cambiar_contraseña():
    """
    Cambiar contraseña del usuario logueado
    """
    if request.method == 'POST':
        contraseña_actual = request.form['contraseña_actual']
        nueva_contraseña = request.form['nueva_contraseña']
        confirmar_contraseña = request.form['confirmar_contraseña']
        
        usuario = Usuario.query.get(session['user_id'])
        
        # Verificar contraseña actual
        if not usuario.verificar_contraseña(contraseña_actual):
            flash('La contraseña actual es incorrecta', 'error')
            return render_template('cambiar_contraseña.html')
        
        # Validar nueva contraseña
        if nueva_contraseña != confirmar_contraseña:
            flash('Las contraseñas no coinciden', 'error')
            return render_template('cambiar_contraseña.html')
        
        es_valida, mensaje = validar_contraseña(nueva_contraseña)
        if not es_valida:
            flash(mensaje, 'error')
            return render_template('cambiar_contraseña.html')
        
        # Establecer nueva contraseña
        usuario.establecer_contraseña(nueva_contraseña)
        db.session.commit()
        
        flash('Contraseña cambiada exitosamente', 'success')
        return redirect(url_for('index'))
    
    return render_template('cambiar_contraseña.html')

# Rutas de gestión de usuarios
@app.route('/usuarios')
@permiso_required('usuarios')
def usuarios():
    """
    Mostrar todos los usuarios
    """
    usuarios = Usuario.query.all()
    return render_template('usuarios.html', usuarios=usuarios)

@app.route('/usuario/agregar', methods=['GET', 'POST'])
@permiso_required('usuarios')
def agregar_usuario():
    """
    Agregar un nuevo usuario
    """
    if request.method == 'POST':
        try:
            # Validar contraseña
            contraseña = request.form['contraseña']
            confirmar_contraseña = request.form['confirmar_contraseña']
            
            if contraseña != confirmar_contraseña:
                flash('Las contraseñas no coinciden', 'error')
                return render_template('agregar_usuario.html')
            
            es_valida, mensaje = validar_contraseña(contraseña)
            if not es_valida:
                flash(mensaje, 'error')
                return render_template('agregar_usuario.html')
            
            # Verificar email único
            if Usuario.query.filter_by(email=request.form['email']).first():
                flash('El email ya está registrado', 'error')
                return render_template('agregar_usuario.html')
            
            # Verificar DNI único
            if Usuario.query.filter_by(dni=request.form['dni']).first():
                flash('El DNI ya está registrado', 'error')
                return render_template('agregar_usuario.html')
            
            usuario = Usuario(
                nombre_apellido=request.form['nombre_apellido'],
                email=request.form['email'],
                dni=request.form['dni'],
                calle=request.form['calle'],
                numero=request.form['numero'],
                codigo_postal=request.form['codigo_postal'],
                rol=request.form['rol']
            )
            
            usuario.establecer_contraseña(contraseña)
            
            db.session.add(usuario)
            db.session.commit()
            flash('¡Usuario agregado exitosamente!', 'success')
            return redirect(url_for('usuarios'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el usuario: {str(e)}', 'error')
    
    return render_template('agregar_usuario.html')

@app.route('/usuario/editar/<int:id>', methods=['GET', 'POST'])
@permiso_required('usuarios')
def editar_usuario(id):
    """
    Editar un usuario existente
    """
    usuario = Usuario.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            # Verificar email único (excepto el usuario actual)
            email_existente = Usuario.query.filter(
                Usuario.email == request.form['email'],
                Usuario.id != id
            ).first()
            if email_existente:
                flash('El email ya está registrado por otro usuario', 'error')
                return render_template('editar_usuario.html', usuario=usuario)
            
            # Verificar DNI único (excepto el usuario actual)
            dni_existente = Usuario.query.filter(
                Usuario.dni == request.form['dni'],
                Usuario.id != id
            ).first()
            if dni_existente:
                flash('El DNI ya está registrado por otro usuario', 'error')
                return render_template('editar_usuario.html', usuario=usuario)
            
            usuario.nombre_apellido = request.form['nombre_apellido']
            usuario.email = request.form['email']
            usuario.dni = request.form['dni']
            usuario.calle = request.form['calle']
            usuario.numero = request.form['numero']
            usuario.codigo_postal = request.form['codigo_postal']
            usuario.rol = request.form['rol']
            usuario.estado = request.form['estado']
            
            # Si se proporciona nueva contraseña, validarla y establecerla
            nueva_contraseña = request.form.get('nueva_contraseña')
            if nueva_contraseña:
                confirmar_contraseña = request.form.get('confirmar_contraseña')
                
                if nueva_contraseña != confirmar_contraseña:
                    flash('Las contraseñas no coinciden', 'error')
                    return render_template('editar_usuario.html', usuario=usuario)
                
                es_valida, mensaje = validar_contraseña(nueva_contraseña)
                if not es_valida:
                    flash(mensaje, 'error')
                    return render_template('editar_usuario.html', usuario=usuario)
                
                usuario.establecer_contraseña(nueva_contraseña)
            
            db.session.commit()
            flash('¡Usuario actualizado exitosamente!', 'success')
            return redirect(url_for('usuarios'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el usuario: {str(e)}', 'error')
    
    return render_template('editar_usuario.html', usuario=usuario)

@app.route('/usuario/eliminar/<int:id>', methods=['POST'])
@permiso_required('usuarios')
def eliminar_usuario(id):
    """
    Eliminar un usuario (marcar como inactivo)
    """
    try:
        usuario = Usuario.query.get_or_404(id)
        
        # No permitir eliminar el propio usuario
        if usuario.id == session['user_id']:
            flash('No puedes eliminar tu propio usuario', 'error')
            return redirect(url_for('usuarios'))
        
        usuario.estado = 'inactivo'
        db.session.commit()
        flash('¡Usuario eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el usuario: {str(e)}', 'error')
    
    return redirect(url_for('usuarios'))

@app.route('/usuario/ver/<int:id>')
@permiso_required('usuarios')
def ver_usuario(id):
    """
    Ver detalles de un usuario
    """
    usuario = Usuario.query.get_or_404(id)
    return render_template('ver_usuario.html', usuario=usuario)

# Rutas de la aplicación
@app.route('/')
@permiso_required('inicio')
def index():
    """
    Página principal que muestra todos los productos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    
    # Calcular estadísticas
    productos_bajo_stock = len([p for p in productos if p.stock_actual <= p.stock_minimo])
    valor_total_productos = sum(p.precio for p in productos)
    margen_total_productos = sum(p.precio - p.costo for p in productos)
    
    return render_template('index.html', 
                         productos=productos,
                         productos_bajo_stock=productos_bajo_stock,
                         valor_total_productos=valor_total_productos,
                         margen_total_productos=margen_total_productos)

@app.route('/producto/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_producto')
def agregar_producto():
    """
    Agregar un nuevo producto
    """
    if request.method == 'POST':
        try:
            producto = Articulo(
                codigo=request.form['codigo'],
                nombre_breve=request.form['nombre_breve'],
                descripcion=request.form['descripcion'],
                costo=float(request.form['costo']) if request.form['costo'] else 0.0,
                precio=float(request.form['precio']) if request.form['precio'] else 0.0,
                id_categoria=int(request.form['id_categoria']),
                id_proveedor=int(request.form['id_proveedor']) if request.form['id_proveedor'] else None,
                stock_actual=int(request.form['stock_actual']) if request.form['stock_actual'] else 0,
                stock_minimo=int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0
            )
            
            db.session.add(producto)
            db.session.commit()
            flash('¡Producto agregado exitosamente!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('agregar_producto.html', categorias=categorias, proveedores=proveedores)

@app.route('/producto/editar/<int:id>', methods=['GET', 'POST'])
@permiso_required('editar_producto')
def editar_producto(id):
    """
    Editar un producto existente
    """
    producto = Articulo.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            producto.codigo = request.form['codigo']
            producto.nombre_breve = request.form['nombre_breve']
            producto.descripcion = request.form['descripcion']
            producto.costo = float(request.form['costo']) if request.form['costo'] else 0.0
            producto.precio = float(request.form['precio']) if request.form['precio'] else 0.0
            producto.id_categoria = int(request.form['id_categoria'])
            producto.id_proveedor = int(request.form['id_proveedor']) if request.form['id_proveedor'] else None
            producto.stock_actual = int(request.form['stock_actual']) if request.form['stock_actual'] else 0
            producto.stock_minimo = int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0
            
            db.session.commit()
            flash('¡Producto actualizado exitosamente!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('editar_producto.html', producto=producto, categorias=categorias, proveedores=proveedores)

@app.route('/producto/eliminar/<int:id>', methods=['POST'])
@permiso_required('eliminar_producto')
def eliminar_producto(id):
    """
    Eliminar un producto (marcar como inactivo)
    """
    try:
        producto = Articulo.query.get_or_404(id)
        producto.activo = False
        db.session.commit()
        flash('¡Producto eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el producto: {str(e)}', 'error')
    
    return redirect(url_for('index'))

@app.route('/producto/ver/<int:id>')
@permiso_required('ver_producto')
def ver_producto(id):
    """
    Ver detalles de un producto
    """
    producto = Articulo.query.get_or_404(id)
    return render_template('ver_producto.html', producto=producto)

@app.route('/api/productos')
@permiso_required('api_productos')
def api_productos():
    """
    API endpoint para obtener todos los productos activos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    productos_json = []
    
    for producto in productos:
        productos_json.append({
            'id': producto.id_articulo,
            'codigo': producto.codigo,
            'nombre_breve': producto.nombre_breve,
            'descripcion': producto.descripcion,
            'costo': producto.costo,
            'precio': producto.precio,
            'stock_actual': producto.stock_actual,
            'stock_minimo': producto.stock_minimo,
            'categoria': producto.categoria.nombre_categoria if producto.categoria else 'Sin categoría',
            'proveedor': producto.proveedor.nombre_proveedor if producto.proveedor else 'Sin proveedor'
        })
    
    return jsonify(productos_json)

@app.route('/stock-bajo')
@permiso_required('stock_bajo')
def stock_bajo():
    """
    Mostrar productos con stock bajo
    """
    productos_bajo_stock = Articulo.query.filter(
        Articulo.stock_actual <= Articulo.stock_minimo,
        Articulo.activo == True
    ).all()
    
    # Calcular estadísticas específicas
    stock_negativo_count = len([p for p in productos_bajo_stock if p.stock_actual < 0])
    stock_cero_count = len([p for p in productos_bajo_stock if p.stock_actual == 0])
    valor_total_alertas = sum(p.precio for p in productos_bajo_stock)
    
    return render_template('stock_bajo.html', 
                         productos=productos_bajo_stock,
                         stock_negativo_count=stock_negativo_count,
                         stock_cero_count=stock_cero_count,
                         valor_total_alertas=valor_total_alertas)

# Categorías CRUD
@app.route('/categorias')
@permiso_required('categorias')
def categorias():
    """
    Mostrar todas las categorías
    """
    categorias = Categoria.query.filter_by(activo=True).all()
    return render_template('categorias.html', categorias=categorias)

@app.route('/categoria/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_categoria')
def agregar_categoria():
    """
    Agregar una nueva categoría
    """
    if request.method == 'POST':
        try:
            categoria = Categoria(
                nombre_categoria=request.form['nombre_categoria'],
                descripcion=request.form['descripcion']
            )
            
            db.session.add(categoria)
            db.session.commit()
            flash('¡Categoría agregada exitosamente!', 'success')
            return redirect(url_for('categorias'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar la categoría: {str(e)}', 'error')
    
    return render_template('agregar_categoria.html')

@app.route('/proveedores')
@permiso_required('proveedores')
def proveedores():
    """
    Mostrar todos los proveedores
    """
    proveedores = Proveedor.query.filter_by(activo=True).all()
    
    # Calcular estadísticas de proveedores
    proveedores_con_email = len([p for p in proveedores if p.email])
    proveedores_con_telefono = len([p for p in proveedores if p.telefono])
    
    return render_template('proveedores.html', 
                         proveedores=proveedores,
                         proveedores_con_email=proveedores_con_email,
                         proveedores_con_telefono=proveedores_con_telefono)

@app.route('/proveedor/agregar', methods=['GET', 'POST'])
@permiso_required('agregar_proveedor')
def agregar_proveedor():
    """
    Agregar un nuevo proveedor
    """
    if request.method == 'POST':
        try:
            proveedor = Proveedor(
                nombre_proveedor=request.form['nombre_proveedor'],
                contacto=request.form['contacto'] if request.form['contacto'] else None,
                telefono=request.form['telefono'] if request.form['telefono'] else None,
                email=request.form['email'] if request.form['email'] else None,
                direccion=request.form['direccion'] if request.form['direccion'] else None
            )
            
            db.session.add(proveedor)
            db.session.commit()
            flash('¡Proveedor agregado exitosamente!', 'success')
            return redirect(url_for('proveedores'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el proveedor: {str(e)}', 'error')
    
    return render_template('agregar_proveedor.html')

def inicializar_datos():
    """
    Inicializar la base de datos con datos de ejemplo
    """
    # Inicializar usuario administrador por defecto
    if not Usuario.query.first():
        print("Inicializando usuario administrador...")
        admin = Usuario(
            nombre_apellido='Administrador del Sistema',
            email='admin@sistema.com',
            dni='12345678',
            calle='Av. Principal',
            numero='123',
            codigo_postal='1000',
            rol='administrador'
        )
        admin.establecer_contraseña('Admin123!')
        db.session.add(admin)
        db.session.commit()
        print("Usuario administrador creado: admin@sistema.com / Admin123!")
    
    if not Categoria.query.first():
        print("Inicializando categorías...")
        categorias_ejemplo = [
            Categoria(nombre_categoria='Linea Estandar', descripcion='Productos de línea estándar con características básicas'),
            Categoria(nombre_categoria='Linea Media', descripcion='Productos de línea media con características intermedias'),
            Categoria(nombre_categoria='Linea Premium', descripcion='Productos de línea premium con características avanzadas')
        ]
        
        for cat in categorias_ejemplo:
            db.session.add(cat)
        
        db.session.commit()
    
    if not Proveedor.query.first():
        print("Inicializando proveedores...")
        proveedores_ejemplo = [
            Proveedor(
                nombre_proveedor='Proveedor ABC S.A.',
                contacto='Juan Pérez',
                telefono='011-1234-5678',
                email='contacto@proveedorabc.com',
                direccion='Av. Corrientes 1234, CABA'
            ),
            Proveedor(
                nombre_proveedor='Distribuidora XYZ',
                contacto='María González',
                telefono='011-9876-5432',
                email='ventas@distribuidoraxyz.com',
                direccion='Av. Santa Fe 5678, CABA'
            ),
            Proveedor(
                nombre_proveedor='Importadora DEF',
                contacto='Carlos López',
                telefono='011-5555-1234',
                email='info@importadoradef.com',
                direccion='Av. Rivadavia 9012, CABA'
            )
        ]
        
        for prov in proveedores_ejemplo:
            db.session.add(prov)
        
        db.session.commit()
    
    if not Articulo.query.first():
        print("Inicializando artículos de ejemplo...")
        articulos_ejemplo = [
            Articulo(
                codigo='ART001',
                nombre_breve='Laptop HP 15',
                descripcion='Laptop HP Pavilion 15 pulgadas, Intel i5, 8GB RAM, 256GB SSD',
                costo=450.00,
                precio=650.00,
                id_categoria=1,  # Linea Media
                id_proveedor=1,
                stock_actual=10,
                stock_minimo=2
            ),
            Articulo(
                codigo='ART002',
                nombre_breve='Mouse Inalámbrico',
                descripcion='Mouse óptico inalámbrico Logitech M705',
                costo=25.00,
                precio=45.00,
                id_categoria=1,  # Linea Estandar
                id_proveedor=2,
                stock_actual=50,
                stock_minimo=10
            ),
            Articulo(
                codigo='ART003',
                nombre_breve='Teclado Mecánico',
                descripcion='Teclado mecánico RGB Corsair K70',
                costo=80.00,
                precio=120.00,
                id_categoria=3,  # Linea Premium
                id_proveedor=1,
                stock_actual=15,
                stock_minimo=5
            ),
            Articulo(
                codigo='ART004',
                nombre_breve='Monitor 24"',
                descripcion='Monitor LED 24 pulgadas Full HD Samsung',
                costo=180.00,
                precio=280.00,
                id_categoria=2,  # Linea Media
                id_proveedor=3,
                stock_actual=8,
                stock_minimo=3
            )
        ]
        
        for art in articulos_ejemplo:
            db.session.add(art)
        
        db.session.commit()
        print("¡Base de datos inicializada exitosamente!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        inicializar_datos()
    
    app.run(debug=True, host='0.0.0.0', port=5000)

