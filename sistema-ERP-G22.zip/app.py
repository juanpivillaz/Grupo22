from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import os

# Configuración de la aplicación Flask
app = Flask(__name__)
app.config['SECRET_KEY'] = 'tu_clave_secreta_aqui_2025'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///productos.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Inicializar SQLAlchemy
db = SQLAlchemy(app)

# Modelo para cada tabla de la base de datos
class Categoria(db.Model):
    __tablename__ = 'categorias'
    id_categoria = db.Column(db.Integer, primary_key=True)
    nombre_categoria = db.Column(db.String(100), unique=True, nullable=False)
    descripcion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Categoria {self.nombre_categoria}>'

class Proveedor(db.Model):
    __tablename__ = 'proveedores'
    id_proveedor = db.Column(db.Integer, primary_key=True)
    nombre_proveedor = db.Column(db.String(100), nullable=False)
    contacto = db.Column(db.String(100))
    telefono = db.Column(db.String(20))
    email = db.Column(db.String(100))
    direccion = db.Column(db.Text)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    def __repr__(self):
        return f'<Proveedor {self.nombre_proveedor}>'

class Articulo(db.Model):
    __tablename__ = 'articulos'
    id_articulo = db.Column(db.Integer, primary_key=True)
    codigo = db.Column(db.String(50), unique=True, nullable=False)
    nombre_breve = db.Column(db.String(100), nullable=False)
    descripcion = db.Column(db.Text)
    costo = db.Column(db.Float, nullable=False, default=0.0)
    precio = db.Column(db.Float, nullable=False, default=0.0)
    id_proveedor = db.Column(db.Integer, db.ForeignKey('proveedores.id_proveedor'))
    id_categoria = db.Column(db.Integer, db.ForeignKey('categorias.id_categoria'), nullable=False)
    stock_actual = db.Column(db.Integer, default=0)
    stock_minimo = db.Column(db.Integer, default=0)
    fecha_registro = db.Column(db.DateTime, default=datetime.utcnow)
    activo = db.Column(db.Boolean, default=True)
    
    # Relaciones
    categoria = db.relationship('Categoria', backref='articulos')
    proveedor = db.relationship('Proveedor', backref='articulos')
    
    def __repr__(self):
        return f'<Articulo {self.nombre_breve}>'

# Rutas de la aplicación
@app.route('/')
def index():
    """
    Página principal que muestra todos los productos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    
    # Calcular estadísticas
    productos_bajo_stock = len([p for p in productos if p.stock_actual <= p.stock_minimo])
    valor_total_productos = sum(p.precio for p in productos)
    margen_total_productos = sum(p.precio - p.costo for p in productos)
    
    return render_template('index.html', 
                         productos=productos,
                         productos_bajo_stock=productos_bajo_stock,
                         valor_total_productos=valor_total_productos,
                         margen_total_productos=margen_total_productos)

@app.route('/producto/agregar', methods=['GET', 'POST'])
def agregar_producto():
    """
    Agregar un nuevo producto
    """
    if request.method == 'POST':
        try:
            producto = Articulo(
                codigo=request.form['codigo'],
                nombre_breve=request.form['nombre_breve'],
                descripcion=request.form['descripcion'],
                costo=float(request.form['costo']) if request.form['costo'] else 0.0,
                precio=float(request.form['precio']) if request.form['precio'] else 0.0,
                id_categoria=int(request.form['id_categoria']),
                id_proveedor=int(request.form['id_proveedor']) if request.form['id_proveedor'] else None,
                stock_actual=int(request.form['stock_actual']) if request.form['stock_actual'] else 0,
                stock_minimo=int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0
            )
            
            db.session.add(producto)
            db.session.commit()
            flash('¡Producto agregado exitosamente!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('agregar_producto.html', categorias=categorias, proveedores=proveedores)

@app.route('/producto/editar/<int:id>', methods=['GET', 'POST'])
def editar_producto(id):
    """
    Editar un producto existente
    """
    producto = Articulo.query.get_or_404(id)
    
    if request.method == 'POST':
        try:
            producto.codigo = request.form['codigo']
            producto.nombre_breve = request.form['nombre_breve']
            producto.descripcion = request.form['descripcion']
            producto.costo = float(request.form['costo']) if request.form['costo'] else 0.0
            producto.precio = float(request.form['precio']) if request.form['precio'] else 0.0
            producto.id_categoria = int(request.form['id_categoria'])
            producto.id_proveedor = int(request.form['id_proveedor']) if request.form['id_proveedor'] else None
            producto.stock_actual = int(request.form['stock_actual']) if request.form['stock_actual'] else 0
            producto.stock_minimo = int(request.form['stock_minimo']) if request.form['stock_minimo'] else 0
            
            db.session.commit()
            flash('¡Producto actualizado exitosamente!', 'success')
            return redirect(url_for('index'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al actualizar el producto: {str(e)}', 'error')
    
    categorias = Categoria.query.filter_by(activo=True).all()
    proveedores = Proveedor.query.filter_by(activo=True).all()
    return render_template('editar_producto.html', producto=producto, categorias=categorias, proveedores=proveedores)

@app.route('/producto/eliminar/<int:id>', methods=['POST'])
def eliminar_producto(id):
    """
    Eliminar un producto (marcar como inactivo)
    """
    try:
        producto = Articulo.query.get_or_404(id)
        producto.activo = False
        db.session.commit()
        flash('¡Producto eliminado exitosamente!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Error al eliminar el producto: {str(e)}', 'error')
    
    return redirect(url_for('index'))

@app.route('/producto/ver/<int:id>')
def ver_producto(id):
    """
    Ver detalles de un producto
    """
    producto = Articulo.query.get_or_404(id)
    return render_template('ver_producto.html', producto=producto)

@app.route('/api/productos')
def api_productos():
    """
    API endpoint para obtener todos los productos activos
    """
    productos = Articulo.query.filter_by(activo=True).all()
    productos_json = []
    
    for producto in productos:
        productos_json.append({
            'id': producto.id_articulo,
            'codigo': producto.codigo,
            'nombre_breve': producto.nombre_breve,
            'descripcion': producto.descripcion,
            'costo': producto.costo,
            'precio': producto.precio,
            'stock_actual': producto.stock_actual,
            'stock_minimo': producto.stock_minimo,
            'categoria': producto.categoria.nombre_categoria if producto.categoria else 'Sin categoría',
            'proveedor': producto.proveedor.nombre_proveedor if producto.proveedor else 'Sin proveedor'
        })
    
    return jsonify(productos_json)

@app.route('/stock-bajo')
def stock_bajo():
    """
    Mostrar productos con stock bajo
    """
    productos_bajo_stock = Articulo.query.filter(
        Articulo.stock_actual <= Articulo.stock_minimo,
        Articulo.activo == True
    ).all()
    
    # Calcular estadísticas específicas
    stock_negativo_count = len([p for p in productos_bajo_stock if p.stock_actual < 0])
    stock_cero_count = len([p for p in productos_bajo_stock if p.stock_actual == 0])
    valor_total_alertas = sum(p.precio for p in productos_bajo_stock)
    
    return render_template('stock_bajo.html', 
                         productos=productos_bajo_stock,
                         stock_negativo_count=stock_negativo_count,
                         stock_cero_count=stock_cero_count,
                         valor_total_alertas=valor_total_alertas)

# Categorías CRUD
@app.route('/categorias')
def categorias():
    """
    Mostrar todas las categorías
    """
    categorias = Categoria.query.filter_by(activo=True).all()
    return render_template('categorias.html', categorias=categorias)

@app.route('/categoria/agregar', methods=['GET', 'POST'])
def agregar_categoria():
    """
    Agregar una nueva categoría
    """
    if request.method == 'POST':
        try:
            categoria = Categoria(
                nombre_categoria=request.form['nombre_categoria'],
                descripcion=request.form['descripcion']
            )
            
            db.session.add(categoria)
            db.session.commit()
            flash('¡Categoría agregada exitosamente!', 'success')
            return redirect(url_for('categorias'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar la categoría: {str(e)}', 'error')
    
    return render_template('agregar_categoria.html')

@app.route('/proveedores')
def proveedores():
    """
    Mostrar todos los proveedores
    """
    proveedores = Proveedor.query.filter_by(activo=True).all()
    
    # Calcular estadísticas de proveedores
    proveedores_con_email = len([p for p in proveedores if p.email])
    proveedores_con_telefono = len([p for p in proveedores if p.telefono])
    
    return render_template('proveedores.html', 
                         proveedores=proveedores,
                         proveedores_con_email=proveedores_con_email,
                         proveedores_con_telefono=proveedores_con_telefono)

@app.route('/proveedor/agregar', methods=['GET', 'POST'])
def agregar_proveedor():
    """
    Agregar un nuevo proveedor
    """
    if request.method == 'POST':
        try:
            proveedor = Proveedor(
                nombre_proveedor=request.form['nombre_proveedor'],
                contacto=request.form['contacto'] if request.form['contacto'] else None,
                telefono=request.form['telefono'] if request.form['telefono'] else None,
                email=request.form['email'] if request.form['email'] else None,
                direccion=request.form['direccion'] if request.form['direccion'] else None
            )
            
            db.session.add(proveedor)
            db.session.commit()
            flash('¡Proveedor agregado exitosamente!', 'success')
            return redirect(url_for('proveedores'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Error al agregar el proveedor: {str(e)}', 'error')
    
    return render_template('agregar_proveedor.html')

def inicializar_datos():
    """
    Inicializar la base de datos con datos de ejemplo
    """
    if not Categoria.query.first():
        print("Inicializando categorías...")
        categorias_ejemplo = [
            Categoria(nombre_categoria='Linea Estandar', descripcion='Productos de línea estándar con características básicas'),
            Categoria(nombre_categoria='Linea Media', descripcion='Productos de línea media con características intermedias'),
            Categoria(nombre_categoria='Linea Premium', descripcion='Productos de línea premium con características avanzadas')
        ]
        
        for cat in categorias_ejemplo:
            db.session.add(cat)
        
        db.session.commit()
    
    if not Proveedor.query.first():
        print("Inicializando proveedores...")
        proveedores_ejemplo = [
            Proveedor(
                nombre_proveedor='Proveedor ABC S.A.',
                contacto='Juan Pérez',
                telefono='011-1234-5678',
                email='contacto@proveedorabc.com',
                direccion='Av. Corrientes 1234, CABA'
            ),
            Proveedor(
                nombre_proveedor='Distribuidora XYZ',
                contacto='María González',
                telefono='011-9876-5432',
                email='ventas@distribuidoraxyz.com',
                direccion='Av. Santa Fe 5678, CABA'
            ),
            Proveedor(
                nombre_proveedor='Importadora DEF',
                contacto='Carlos López',
                telefono='011-5555-1234',
                email='info@importadoradef.com',
                direccion='Av. Rivadavia 9012, CABA'
            )
        ]
        
        for prov in proveedores_ejemplo:
            db.session.add(prov)
        
        db.session.commit()
    
    if not Articulo.query.first():
        print("Inicializando artículos de ejemplo...")
        articulos_ejemplo = [
            Articulo(
                codigo='ART001',
                nombre_breve='Laptop HP 15',
                descripcion='Laptop HP Pavilion 15 pulgadas, Intel i5, 8GB RAM, 256GB SSD',
                costo=450.00,
                precio=650.00,
                id_categoria=1,  # Linea Media
                id_proveedor=1,
                stock_actual=10,
                stock_minimo=2
            ),
            Articulo(
                codigo='ART002',
                nombre_breve='Mouse Inalámbrico',
                descripcion='Mouse óptico inalámbrico Logitech M705',
                costo=25.00,
                precio=45.00,
                id_categoria=1,  # Linea Estandar
                id_proveedor=2,
                stock_actual=50,
                stock_minimo=10
            ),
            Articulo(
                codigo='ART003',
                nombre_breve='Teclado Mecánico',
                descripcion='Teclado mecánico RGB Corsair K70',
                costo=80.00,
                precio=120.00,
                id_categoria=3,  # Linea Premium
                id_proveedor=1,
                stock_actual=15,
                stock_minimo=5
            ),
            Articulo(
                codigo='ART004',
                nombre_breve='Monitor 24"',
                descripcion='Monitor LED 24 pulgadas Full HD Samsung',
                costo=180.00,
                precio=280.00,
                id_categoria=2,  # Linea Media
                id_proveedor=3,
                stock_actual=8,
                stock_minimo=3
            )
        ]
        
        for art in articulos_ejemplo:
            db.session.add(art)
        
        db.session.commit()
        print("¡Base de datos inicializada exitosamente!")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        inicializar_datos()
    
    app.run(debug=True, host='0.0.0.0', port=5000)

